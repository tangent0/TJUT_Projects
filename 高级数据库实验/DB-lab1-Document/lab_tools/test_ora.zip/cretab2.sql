drop table part2;
create table part2
 	(part_id	number(5),
	part_name	char(15),
	status		char(1) default 'A');

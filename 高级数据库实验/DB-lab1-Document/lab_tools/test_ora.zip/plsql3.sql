declare
    num  number := 100;
begin
    del_emp(num); 	/* delete employee 100 */
    commit;
end;
/
